#pragma once


void testAllExtended();

