#include "SMMIterator.h"
#include "SortedMultiMap.h"
#include <iostream>
#include <vector>
#include <exception>
using namespace std;

SortedMultiMap::SortedMultiMap(Relation r) {
    this->r = r;
}

void SortedMultiMap::add(TKey c, TValue v) {
    for (int i = 0; i < this->slla.capacity; i++)
    {
        //add in al doilea slla
        if (this->slla.elems[i].first == c)
        {
            if (slla.elems[i].second.size == 0)
            {
                int currentPos = this->slla.head, isHead = 1, prev = currentPos;
                if (this->slla.size > 0)
                    while (this->r(this->slla.elems[currentPos].first, c) && currentPos != -1)
                    {
                        prev = currentPos;
                        currentPos = this->slla.next[currentPos];
                        isHead = 0;
                    }

                SLLA<TValue> values;
                values.addSLLA(v, 0, 0);
                pair<TKey, SLLA<TValue>>elem(c, values);
                this->slla.addSLLA(elem, prev, isHead);
            }
            else
            {
                this->slla.elems[i].second.addSLLA(v, 0, 0);
                this->slla.size++;
            }
            return;
        }
    }

    SLLA<TValue> values;
    values.addSLLA(v, 0, 0);
    pair<TKey, SLLA<TValue>>elem(c, values);

    int currentPos = this->slla.head, isHead = 1, prev = 0;
    if (this->slla.size > 0)
        while (this->r(this->slla.elems[currentPos].first, c) && currentPos != -1)
        {
            prev = currentPos;
            currentPos = this->slla.next[currentPos];
            isHead = 0;
        }

    this->slla.addSLLA(elem, prev, isHead);
}

vector<TValue> SortedMultiMap::search(TKey c) const {
    vector<TValue> values;
    int current = slla.head;
    bool ok = false;
    //cautam cheia
    for (int i = 0; i < this->slla.capacity; i++) {
        if (this->slla.elems[i].first == c && this->slla.elems[i].second.size > 0)
        {
            current = i;
            ok = true;
            break;
        }
    }
    //daca nu exista iesim
    if (!ok)
        return values;
    //daca exista, adaugam valoriile in vector
    int currentValue = this->slla.elems[current].second.head;
    while (currentValue != -1) {
        values.push_back(this->slla.elems[current].second.elems[currentValue]);
        currentValue = this->slla.elems[current].second.next[currentValue];
    }
    return values;
}

bool SortedMultiMap::remove(TKey c, TValue v) {
    vector<TValue> values = this->search(c);
    SLLA<TValue> value;
    value.addSLLA(v, 0, 0);
    pair<TKey, SLLA<TValue>>elem(c, value);

    if (values.size() == 1)
    {
        bool ok = false;
        for (int i = 0; i < values.size(); ++i)
            if (v == values[i])
                ok = true;
        if (ok)
            if (this->slla.removeSLLAPair(elem))
                return true;
    }
    else {
        for (int i = 0; i < this->slla.capacity; i++) {
            if (this->slla.elems[i].first == c) {
                if (slla.elems[i].second.removeSLLAValue(v)) {
                    this->slla.size--;
                    return true;
                }
            }
        }
    }
    return false;
}


int SortedMultiMap::size() const {

    return this->slla.size;
}

bool SortedMultiMap::isEmpty() const {
    return this->slla.size == 0;
}

SMMIterator SortedMultiMap::iterator() const {
    return SMMIterator(*this);
}

SortedMultiMap::~SortedMultiMap() {
    for (int i = 0; i < this->slla.capacity; i++) {
        delete[] this->slla.elems[i].second.elems;
        delete[] this->slla.elems[i].second.next;
    }
    delete[] this->slla.elems;
    delete[] this->slla.next;
}
