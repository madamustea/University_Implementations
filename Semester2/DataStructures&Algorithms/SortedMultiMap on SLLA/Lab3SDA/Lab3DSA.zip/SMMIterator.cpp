#include "SMMIterator.h"
#include "SortedMultiMap.h"
#include<iostream>
SMMIterator::SMMIterator(const SortedMultiMap& d) : map(d) {
    indexElem = this->map.slla.head;
    indexValue = this->map.slla.elems[indexElem].second.head;
}

void SMMIterator::first() {
    indexElem = this->map.slla.head;
    indexValue = this->map.slla.elems[indexElem].second.head;
}

void SMMIterator::next() {
    if (valid()) {
        if (this->map.slla.elems[indexElem].second.next[indexValue] == -1) {
            indexElem = this->map.slla.next[indexElem];
            indexValue = this->map.slla.elems[indexElem].second.head;
        }
        else {
            indexValue = this->map.slla.elems[indexElem].second.next[indexValue];
        }
    }
    else throw std::exception();
}
void SMMIterator::nextKey() {
    if (valid()) {
        indexElem = this->map.slla.next[indexElem];
        indexValue = this->map.slla.elems[indexElem].second.head;
    }
    else throw std::exception();
}
bool SMMIterator::valid() const {
    if (indexValue == -1 || indexElem == -1)
        return false;
    return true;
}
TElem SMMIterator::getCurrent() const {
    if (valid()) {
        pair<TKey, TValue> pair(this->map.slla.elems[indexElem].first, this->map.slla.elems[indexElem].second.elems[indexValue]);
        return pair;
    }
    else throw std::exception();
}


