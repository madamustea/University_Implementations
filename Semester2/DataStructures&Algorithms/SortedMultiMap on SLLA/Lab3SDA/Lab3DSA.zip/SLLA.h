#pragma once
#include <vector>
#include <utility>
#include"SortedMultiMap.h"
template <class type>
class SLLA {
    friend class SortedMultiMap;
public:

    int capacity{};
    type* elems;
    int* next{};
    int head{};
    int firstEmpty{};
    int size = 0;


    SLLA() {

        this->capacity = 5;
        this->elems = new type[this->capacity];
        this->next = new int[this->capacity];
        this->head = -1;
        for (int i = 0; i < this->capacity; i++) {
            this->next[i] = i + 1;
        }
        this->next[this->capacity - 1] = -1;
        this->firstEmpty = 0;
    }
    void expand() {

        int oldCapacity = capacity;
        this->capacity *= 2;
        type* tempElems = new type[this->capacity];
        int* tempNext = new int[this->capacity];

        for (int i = oldCapacity; i < this->capacity; i++) {
            tempNext[i] = i + 1;
        }
        tempNext[this->capacity - 1] = -1;
        for (int i = 0; i < oldCapacity; i++) {
            tempElems[i] = elems[i];
            tempNext[i] = next[i];
        }
        delete[] this->elems;
        delete[] this->next;
        this->elems = tempElems;
        this->next = tempNext;
        this->firstEmpty = oldCapacity;
        this->next[this->capacity - 1] = -1;
    }

    void addSLLA(type elem, int prevPosition, int isHead) {

        int nextFE = -1;
        if (firstEmpty < 0)this->expand();

        if (firstEmpty >= 0)
            nextFE = next[firstEmpty];
        elems[firstEmpty] = elem;

        if (size == 0)
        {
            next[firstEmpty] = -1;
            this->head = firstEmpty;
        }
        else
        {
            if (isHead == 1)
            {
                next[firstEmpty] = head;
                head = firstEmpty;
            }
            else
            {
                next[firstEmpty] = next[prevPosition];
                next[prevPosition] = firstEmpty;
            }
        }
        firstEmpty = nextFE;
        size++;
    }
    bool removeSLLAValue(type elem) {
        int current = this->head;
        int prev = -1;
        while (current != -1 && this->elems[current] != elem) {
            prev = current;
            current = this->next[current];
        }
        if (current != -1)
        {
            if (current == this->head) {
                this->head = this->next[head];

            }
            else {
                this->next[prev] = this->next[current];
            }
            this->next[current] = this->firstEmpty;
            this->firstEmpty = current;
        }
        else {

            return false;
        }
        this->size--;
        return true;
    }

    bool removeSLLAPair(type elem) {
        int current = this->head;
        int prev = -1;

        while (current != -1 && this->elems[current].first != elem.first) {
            prev = current;
            current = this->next[current];
        }
        if (current != -1)
        {
            if (current == this->head) {
                this->head = this->next[head];

            }
            else {
                this->next[prev] = this->next[current];
            }
            this->next[current] = this->firstEmpty;
            this->firstEmpty = current;
        }
        else {

            return false;
        }
        this->size--;
        return true;
    }

    ~SLLA() {


    }
};
